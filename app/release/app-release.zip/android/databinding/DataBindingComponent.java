package android.databinding;

public interface DataBindingComponent {
}
